import { showView } from './util.js';

const section = document.querySelector('#form-sign-up');

export function registerPage() {
    showView(section);
}