import { updateView } from "./utils.js";

// const routes = {
//     '/': homePage,
//     '/login': login,
//     '/logout': logout,
//     '/register': register,
//     '/create': create,
// };

updateView();